package com.deepcoomer.alarmclock;

public class interger {
}
