package com.deepcoomer.alarmclock;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextClock;
import android.widget.TimePicker;

import java.util.Timer;
import java.util.TimerTask;

import static android.media.RingtoneManager.*;

public class MainActivity extends AppCompatActivity {
TimePicker alarmTime;
TextClock currentTime;

    }
    }